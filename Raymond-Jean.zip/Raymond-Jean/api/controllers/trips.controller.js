const { model } = require("mongoose");

const Trip = model("Trip");

const getAllTrips = (req, res) => {
  if (req.query && req.query.lng && req.query.lat) {
    runGeoQuery(req, res);
  } else {
    // validate request
    const checked = validateRequest(req);
    if (checked.error) {
      res.status(checked.error.status).json(checked.error);
      return;
    } else {
      //find docs
      Trip.find()
        .skip(checked.offset)
        .sort({ _id: -1 })
        .limit(checked.count)
        .exec((err, docs) => {
          if (err) {
            res.status(500).json(err);
            return;
          }
          res.status(200).json(docs);
        });
    }
  }
};

const getOneTrip = (req, res) => {
  Trip.findById(req.params.tripId, (err, doc) => {
    if (err) {
      res.status(500).json(err);
      return;
    }
    if (!doc) {
      res.status(404).json({
        error: "404 - Not found",
        message: "We're sorry, but we don't have a Trip for this ID.",
      });
      return;
    }
    res.status(200).json(doc);
  });
};

const addNewTrip = (req, res) => {
  console.log("add new Trip");
  const newTrip = new Trip(req.body);
  newTrip.save((err, trip) => {
    if (err) {
      res.status(500).json(err);
    }
    res.status(201).json(trip);
  });
};

const updateTrip = (req, res) => {
  console.log("update Trip");
  Trip.findByIdAndUpdate(
    req.params.tripId,
    req.body,
    { new: true, useFindAndModify: false },
    (err, Trip) => {
      if (err) {
        res.status(500).json(err);
        return;
      }
      if (!Trip) {
        res.status(404).json({
          error: "404 - Not found",
          message: "We're sorry, but we don't have a Trip for this ID.",
        });
        return;
      }
      res.status(200).json(Trip);
    }
  );
};

const deleteTrip = (req, res) => {
  console.log("delete Trip");
  Trip.findByIdAndDelete(req.params.tripId, (err, doc) => {
    if (err) {
      res.status(500).json(err);
      return;
    }
    if (!doc) {
      res.status(404).json({
        error: "404 - Not found",
        message: "We're sorry, but we don't have a Trip for this ID.",
      });
      return;
    }
    res.status(200).json(doc);
  });
};

const validateRequest = (req, count = 6, offset = 0, maxCount = 10) => {
  const error = { name: "Bad request", status: 400 };

  // user input exist
  if (req.query && req.query.count) {
    count = parseInt(req.query.count, 10);
  }
  if (req.query && req.query.offset) {
    offset = parseInt(req.query.offset, 10);
  }
  // user input numbers
  if (isNaN(count) || isNaN(offset)) {
    error.message = "QueryString Offset and Count should be numbers";
  }
  // limit check
  if (count > maxCount) {
    error.message = `Cannot exceed count of ${maxCount}`;
  }

  if (error.message) {
    return { error };
  } else {
    return {
      count,
      offset,
    };
  }
};

const runGeoQuery = function (req, res) {
  const lng = parseFloat(req.query.lng);

  const lat = parseFloat(req.query.lat);

  const maxDist = parseFloat(req.query.dist) || 1000;

  console.log("lng", lng, " lat ", lat, " dist ", maxDist);

  const query = {
    "start station location": {
      $near: {
        $geometry: {
          type: "Point",

          coordinates: [lng, lat],
        },

        $maxDistance: maxDist,

        $minDistance: 0,
      },
    },
  };

  Trip.find(query).exec(function (err, trips) {
    console.log("Geo Search");

    if (err) {
      console.log("Error", err);

      return;
    }

    console.log("found trips");

    res.status(200).json(trips);
  });
};

module.exports = {
  getAllTrips,
  getOneTrip,
  addNewTrip,
  updateTrip,
  deleteTrip,
};
