const mongoose = require("mongoose");

const TripSchema = mongoose.Schema({
  tripduration: Number,
  "start station id": String,
  "start station name": String,
  "end station id": Number,
  "end station name": String,
  bikeid: Number,
  usertype: String,
  "birth year": Number,
  gender: Number,
  "start station location": {
    type: {
      type: String,
    },
    coordinates: {
      type: [Number],
      index: "2dsphere",
    },
  },
  "end station location": {
    type: {
      type: String,
    },
    coordinates: {
      type: [Number],
      index: "2dsphere",
    },
  },
  "start time": Date,
  "stop time": Date,
});

mongoose.model("Trip", TripSchema, "trips");
