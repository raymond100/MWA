const express = require("express");
const {
  getAllTrips,
  getOneTrip,
  updateTrip,
  deleteTrip,
} = require("../controllers/trips.controller");

const router = express.Router();

router.route("/trips").get(getAllTrips);

router
  .route("/trips/:tripId")
  .get(getOneTrip)
  .put(updateTrip)
  .delete(deleteTrip);

module.exports = router;
