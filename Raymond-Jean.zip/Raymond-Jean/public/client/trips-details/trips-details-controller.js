angular
  .module("tripsApp")
  .controller("TripsDetailController", TripsDetailController);

function TripsDetailController(TripsFactory, $routeParams, $window) {
  const vm = this;
  const tripId = $routeParams.tripsId;
  TripsFactory.getOneTrip(tripId).then((data) => {
    vm.details = data;
  });

  vm.deleteTrip = function (tripId) {
    console.log(tripId);
    TripsFactory.deleteTrip(tripId).then((data) => {
      if (!data.status) {
        TripsFactory.alertMessage("trips successfuly deleted!");
        $window.location.href = "#!/trips";
      } else {
        vm.messageErrorAlert = "Oupss! An error has occured. Try again";
      }
    });
  };
}
