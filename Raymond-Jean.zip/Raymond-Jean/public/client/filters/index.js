angular.module("tripsApp").filter("HoursFilters", HoursFilters);

function HoursFilters() {
  return function (hours) {
    if (hours && !isNaN(hours)) {
    }
  };
}
