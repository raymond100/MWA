angular.module("tripsApp").controller("TripsController", TripsController);

function TripsController(TripsFactory) {
  const vm = this;
  const message = TripsFactory.getMessage();
  // TODO: Get count in the DB.
  const tripFiltered = 100;
  // TODO: Generate number page auto
  const perPage = 10;
  vm.currentPage = 0;

  let offset = perPage * vm.currentPage;

  callTrips(TripsFactory, vm, offset, perPage);

  vm.setCurrentPage = function (val) {
    vm.currentPage = val;
    offset = perPage * vm.currentPage;
    callTrips(TripsFactory, vm, offset, perPage);
  };

  vm.nextPage = function (val) {
    if (offset < tripFiltered) {
      vm.currentPage = parseInt(val) + 1;
      offset = perPage * vm.currentPage;
      console.log(offset);
      callTrips(TripsFactory, vm, offset, perPage);
    }
  };

  vm.previousPage = function (val) {
    if (vm.currentPage > 0) {
      vm.currentPage = parseInt(val) - 1;
      offset = perPage * vm.currentPage;
      callTrips(TripsFactory, vm, offset, perPage);
    }
  };

  vm.search = function () {
    if (vm.lng && vm.lat && vm.dist) {
      callTripSearch(
        TripsFactory,
        vm,
        offset,
        perPage,
        vm.lng,
        vm.lat,
        vm.dist
      );
    }
  };

  if (message != "") {
    vm.successMessage = message;
    TripsFactory.resetAlert();
  }
}

const callTrips = function (factory, ctx, offset, perPage) {
  factory.getAllTrips(offset, perPage).then((response) => {
    ctx.allTrips = response;
  });
};

const callTripSearch = function (
  factory,
  ctx,
  offset,
  perPage,
  lng,
  lat,
  dist
) {
  factory.getAllTripSearch(offset, perPage, lng, lat, dist).then((response) => {
    ctx.allTrips = response;
  });
};
