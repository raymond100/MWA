angular.module("tripsApp", ["ngRoute"]).config(config);

function config($routeProvider) {
  $routeProvider.when("/", {
    redirectTo: "/trips",
  });
  $routeProvider
    .when("/trips", {
      templateUrl: "client/trips-list/trips-list.html",
      controller: "TripsController",
      controllerAs: "vm",
    })
    .when("/trips/:tripsId", {
      templateUrl: "client/trips-details/trips-details.html",
      controller: "TripsDetailController",
      controllerAs: "vm",
    })
    .otherwise({
      redirectTo: "/",
    });
}
