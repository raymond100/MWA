angular.module("tripsApp").factory("TripsFactory", TripsFactory);

function TripsFactory($http) {
  let messageAlert = "";

  function getAllTrips(
    offset,
    count,
    lng = undefined,
    lat = undefined,
    dist = undefined
  ) {
    return $http
      .get(`/api/trips?offset=${offset}&count=${count}`)
      .then(complete)
      .catch(failed);
  }

  function getAllTripSearch(offset, count, lng, lat, dist) {
    return $http
      .get(
        `/api/trips?offset=${offset}&count=${count}&lng=${lng}&lat=${lat}$dist=${dist}`
      )
      .then(complete)
      .catch(failed);
  }

  function getOneTrip(tripsId) {
    return $http.get(`/api/trips/${tripsId}`).then(complete).catch(failed);
  }

  function deleteTrip(tripsId) {
    return $http.delete(`/api/trips/${tripsId}`).then(complete).catch(failed);
  }
  function complete(response) {
    return response.data;
  }
  function failed(error) {
    return error;
  }

  function alertMessage(message) {
    messageAlert = message;
  }

  function getMessage() {
    return messageAlert;
  }

  function resetAlert() {
    setTimeout(() => {
      document.querySelector(".alert").style.display = "none";
      messageAlert = "";
    }, 2000);
  }

  return {
    getAllTrips,
    getOneTrip,
    deleteTrip,
    alertMessage,
    getMessage,
    resetAlert,
    getAllTripSearch,
  };
}
